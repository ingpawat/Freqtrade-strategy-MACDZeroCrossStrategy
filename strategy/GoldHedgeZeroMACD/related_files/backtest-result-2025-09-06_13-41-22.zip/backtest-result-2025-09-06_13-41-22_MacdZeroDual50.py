# -*- coding: utf-8 -*-
from datetime import datetime
from typing import Optional

import talib.abstract as ta
import freqtrade.vendor.qtpylib.indicators as qtpylib
import pandas as pd
import logging
from pandas import DataFrame
from freqtrade.strategy import IStrategy
from freqtrade.strategy import IntParameter, DecimalParameter

logger = logging.getLogger(__name__)


class MacdZeroDual50(IStrategy):
    """
    Logic:
      - ซื้อเมื่อ MACD ตัด "เหนือ 0"
      - ขายเมื่อ MACD ตัด "ต่ำกว่า 0"
      - ขนาดไม้ = 50% ของ USDT ที่ 'เหลืออยู่' ณ ตอนเปิดออเดอร์ (ต่อคู่)
      - ใช้คู่ BTC/USDT, PAXG/USDT (ตั้งใน config/pairlist)

    หมายเหตุ:
      - ถ้าทั้ง 2 คู่ให้สัญญาณพร้อมกัน Freqtrade จะส่งคำสั่งทีละคู่
        ทำให้ได้ ~50% + ~25% รวม ~75% ของพอร์ต โดยขึ้นกับลำดับประมวลผล
        (ถ้าต้องการ 50/50 เป๊ะ ให้ตั้ง stake fixed ใน config หรือทำ logic เพิ่มเอง)
    """

    # Required interface version for modern Freqtrade
    INTERFACE_VERSION = 3

    # Change CC_LEN to adjust how many daily candles are used for the BTC↔PAXG correlation window.
    # Larger = smoother & slower; smaller = more reactive & noisier.
    # Correlation window length (number of daily candles)
    CC_LEN: int = 7    # default; easy to change in one place
    
    # Reference asset for correlation (gold proxy)
    REF_GOLD_SPOT: str = "PAXG/USDT:USDT"

    TRADE_PREFIXES: tuple[str, ...] = (
    "BTC/USDT:USDT",
    "ETH/USDT:USDT",
    "SOL/USDT:USDT",
    "PAXG/USDT:USDT",
    "XRP/USDT:USDT",
    "BNB/USDT:USDT",
    "DOGE/USDT:USDT",
    "TRX/USDT:USDT",
    "ADA/USDT:USDT",
    "HYPE/USDT:USDT",
)

    timeframe = '1d'
    minimal_roi = {"0": 1000}
    stoploss = -0.99
    can_short = False
    position_adjustment_enable = False
    startup_candle_count = 60  # เผื่อ EMA26 + สัญญาณ

    # Hyperopt-tunable leverage parameters (discovered via space='protection')
    lev_max: IntParameter = IntParameter(10, 30, default=20, space='protection', optimize=True)
    lev_gamma: DecimalParameter = DecimalParameter(0.5, 3.0, decimals=2, default=1.0, space='protection', optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macdsignal'] = macd['macdsignal']
        dataframe['macdhist'] = macd['macdhist']
        return dataframe

    def informative_pairs(self):
        """Keep PAXG as reference for correlation"""
        pairs = []
        # Keep PAXG as reference for correlation
        pairs.append(("PAXG/USDT:USDT", self.timeframe))
        # optional fallback if you sometimes use spot for CC
        pairs.append(("PAXG/USDT", self.timeframe))
        return pairs

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Generate long entry when MACD crosses above 0."""
        dataframe['enter_long'] = 0
        long_cond = (qtpylib.crossed_above(dataframe['macd'], 0)) & (dataframe['volume'] > 0)
        dataframe.loc[long_cond, ['enter_long', 'enter_tag']] = (1, 'macd_zero_up')
        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        """Exit long when MACD crosses below 0."""
        dataframe['exit_long'] = 0
        dataframe.loc[
            qtpylib.crossed_below(dataframe['macd'], 0),
            ['exit_long', 'exit_tag']
        ] = (1, 'macd_zero_down')
        return dataframe

    def custom_stake_amount(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_stake: float,
        min_stake: Optional[float],
        max_stake: float,
        leverage: float,
        entry_tag: Optional[str],
        side: str,
        **kwargs
    ) -> float:
        """
        ใช้จำนวนคงที่ 100 USDT ต่อออเดอร์ (ปรับตาม min/max และยอดคงเหลือ)
        """

            
        available = self.wallets.get_available_stake_amount()
        stake_amount = 20

        if min_stake is not None and stake_amount < min_stake:
            stake_amount = float(min_stake)
        if max_stake is not None:
            stake_amount = min(stake_amount, float(max_stake))
        stake_amount = min(stake_amount, available)

        return float(max(0.0, stake_amount))

    def _corrN(self, pair: str, ref_pair: str, n: int) -> float | None:
        """Helper to compute N-day correlation between a pair and reference pair."""
        df_a, _ = self.dp.get_analyzed_dataframe(pair=pair, timeframe=self.timeframe)
        df_b = self.dp.get_pair_dataframe(ref_pair, timeframe=self.timeframe)
        if df_a is None or df_b is None:
            return None
        a = df_a[['date', 'close']].copy()
        a['ret'] = a['close'].pct_change()
        b = df_b[['date', 'close']].copy()
        b['ret_ref'] = b['close'].pct_change()
        m = pd.merge(a[['date','ret']], b[['date','ret_ref']], on='date', how='inner').dropna()
        if len(m) < n:
            return None
        cc = m['ret'].tail(n).corr(m['ret_ref'].tail(n))
        return None if pd.isna(cc) else float(cc)

    def leverage(
            self,
            pair: str,
            current_time: datetime,
            current_rate: float,
            proposed_leverage: float,
            max_leverage: float,
            entry_tag: Optional[str],
            side: str,
            **kwargs,
    ) -> float:
        """Dynamic futures leverage by correlation to PAXG.

        Logic:
        - BTC/ETH/SOL: correlate with PAXG futures, scale leverage when cc < 0
        - PAXG: return 1.0 (no leverage, entries blocked by custom_stake_amount)
        - Other pairs: return 1.0
        """
        try:
            if not hasattr(self, 'dp') or self.dp is None:
                return 1.0

            if pair.startswith((self.TRADE_PREFIXES)):
                refs = ["PAXG/USDT:USDT", "PAXG/USDT"]
                cc = None
                used_ref = None
                for r in refs:
                    cc = self._corrN(pair, r, self.CC_LEN)
                    if cc is not None:
                        used_ref = r
                        break
                        
                if cc is None or cc >= 0:
                    return 1.0
                    
                # cc < 0 -> compute leverage
                if hasattr(self, "lev_max") and hasattr(self, "lev_gamma"):
                    n = min(1.0, max(0.0, -cc))
                    lev_max = float(self.lev_max.value)
                    gamma = float(self.lev_gamma.value)
                    lev = 3.0 + (lev_max - 3.0) * (n ** gamma)
                else:
                    lev = 10.0
                    
                if max_leverage is not None:
                    lev = min(lev, float(max_leverage))
                    
                # Log for audit
                logger.info(f"[LEV] {current_time} {pair} cc={cc:.3f} vs {used_ref} lev={lev:.2f} max={max_leverage}")
                
                return float(lev)

            if pair.startswith("PAXG/USDT"):
                return 1.0  # no leverage for PAXG, and entries are blocked by custom_stake_amount

            return 1.0
        except Exception:
            return 1.0
